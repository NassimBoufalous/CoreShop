package main;

public interface Calculatrice {
	public long additionner(int val1, int val2);

	public long soustraire(long val1, int val2);
}
