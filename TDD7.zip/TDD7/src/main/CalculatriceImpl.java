package main;

public class CalculatriceImpl implements Calculatrice {
	@Override
	  public long additionner(int val1, int val2) {
		System.out.println("Debut Appel reel calculatrice");
	    if (val1 <  0 || val2 < 0) {
	      throw new IllegalArgumentException("La valeur ne peut pas etre negative");
	    }
	    System.out.println("Fin Appel reel calculatrice");
	    return val1+val2;
	  }

	 @Override
	  public long soustraire(long val1, int val2) {
	    return val1-val2;
	  }

}
