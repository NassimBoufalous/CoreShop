package main;

public class MonService {
	 protected Calculatrice creerCalculatrice() {
	    return new CalculatriceImpl();
	  }
	  /**
	   * Calculer la somme de deux entiers positifs
	   * @param val1         la premiere valeur
	   * @param val2		 la seconde valeur
	   * @return la somme des deux arguments ou -1 si un des deux arguments est negatif
	   */
	  public long additionnerService(int val1, int val2) {
	    long retour = 0l;
	    Calculatrice calculatrice = creerCalculatrice();

	    try {
	      retour = calculatrice.additionner(val1, val2);
	    	
	    } catch (IllegalArgumentException iae) {
	      retour = -1l;
	    }
	    return retour;
	  }

	  /**
	   * Calculer la somme des deux premiers parametres et soustraire la valeur du troisième
	   * @param val1
	   * @param val2
	   * @param val3
	   * @return le resultat du calcul
	   */
	  public long calculerService(int val1, int val2, int val3) {
	    long retour = 0l;
	    Calculatrice calculatrice = creerCalculatrice();

	    try {
	        long somme = calculatrice.additionner(val1, val2);
		      
	    	retour = calculatrice.soustraire(somme, val3);
	    
		    
	    } catch (IllegalArgumentException iae) {
	      retour = -1l;
	    }

	    return retour;
	  }
	}