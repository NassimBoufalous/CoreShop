package test;

import main.*;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;

public class MonServiceTest {

	private Calculatrice mockedCal;
	MonService monService;

	@Test
	@DisplayName("Test SANS doublure")
	public void testAdditionnerNormal() {

		long retour = 0l;
		monService = new MonService();
		retour = monService.additionnerService(1, 2);
		Assert.assertEquals("La valeur retournee est valide", 3, retour);
	}

	
	
	
	
	
	
	@Test
	@DisplayName("Test AVEC doublure")
	public void testAdditionnerMock() {

		mockedCal = EasyMock.createMock(Calculatrice.class);// creation doublure calculatrice
		
		EasyMock.expect(mockedCal.additionner(1, 2)).andReturn(Long.valueOf(3));
		EasyMock.replay(mockedCal);
		
		monService = new MonService() {// envoi de la doublure au service 
										// il n'y aura pas de création de calculatrice
										// la classe service utilisera la doublure
			@Override
			protected Calculatrice creerCalculatrice() {
				return mockedCal;
			}
		};
		// le reste est identique 
		long retour = monService.additionnerService(1, 2);
		System.out.println(retour);
		Assert.assertEquals("La valeur retournee est valide", 3, retour);
	}
	
	
	
	
	@Test void testDoublureDirect()
	{
		mockedCal = EasyMock.createMock(Calculatrice.class);// creation doublure calculatrice
		
		EasyMock.expect(mockedCal.additionner(1, 2)).andReturn(Long.valueOf(3));
		EasyMock.replay(mockedCal);
		
		long retour = mockedCal.additionner(1, 2);
		System.out.println(retour);
		Assert.assertEquals("La valeur retournee est valide", 3, retour);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@Test
	public void testAdditionnerParametreInvalide() {
		long retour = 0l;
		mockedCal = EasyMock.createMock(Calculatrice.class);// creation doublure calculatrice
		monService = new MonService() {
			@Override
			protected Calculatrice creerCalculatrice() {
				return mockedCal;
			}
		};

		EasyMock.expect(mockedCal.additionner(-1, 2)).andThrow(new IllegalArgumentException());
		EasyMock.replay(mockedCal);

		retour = monService.additionnerService(-1, 2);
		Assert.assertEquals("Parametre Negatif", -1l, retour);
	}

	@Test
	public void testCalculer() {
		long retour = 0l;
		mockedCal = EasyMock.createMock(Calculatrice.class);// creation doublure calculatrice
		monService = new MonService() {
			@Override
			protected Calculatrice creerCalculatrice() {
				return mockedCal;
			}
		};
		
		EasyMock.expect(mockedCal.additionner(20, 30)).andReturn(Long.valueOf(50l));
		EasyMock.expect(mockedCal.soustraire(50, 10)).andReturn(Long.valueOf(40l));
		EasyMock.replay(mockedCal);

		retour = monService.calculerService(20, 30, 10);
		Assert.assertEquals("La valeur retournee est valide", 40l, retour);
	}

}