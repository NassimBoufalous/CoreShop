package main;

import java.util.Set;
import java.util.HashSet;

public class Calculatrice {

	public int add(int a, int b) {

		return a + b;
	}

	public int mul(int a, int b) {

		return a * b;
	}
	
	public int div(int a, int b) {

		if (b == 0)
			return -1;
		else
			return a / b;
	}
	
    public void longCalcul() {
		try {
		    // Attendre 1 secondes
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
    

}
