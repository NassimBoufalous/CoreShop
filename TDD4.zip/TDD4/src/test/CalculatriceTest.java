package test;


import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import main.Calculatrice;
import java.time.Instant;


class CalculatriceTest {
	private Calculatrice cal;
	private static int numTest = 0;
	private static Instant debTest;
	private static Instant endTest;
	
	@BeforeEach
	void initCalc()
	{
		cal= new Calculatrice();
		System.out.println("InitialisationObjetCalc");
	}
	
	
	@BeforeAll
	static void hAvantTousTest(){ 
		
		debTest=Instant.now();
		System.out.println("Tic Toc ...");
	}
	
	
	@ParameterizedTest(name = " {0} * 0 doit être égal à 0")
	@ValueSource(ints = { 1, 2, 42, 1011, 5089 })
	public void multiplication_avecZero_plusieursParam(int arg) {
		// Arrange -- Tout est prêt !

		// Act -- Multiplier par zéro
		int res = cal.mul(arg, 0);

		// Assert -- ça vaut toujours zéro !
		assertEquals(0, res);
	}
	
	
	@ParameterizedTest(name = "{0} * {1} doit être égal à {2}")
	//@ParameterizedTest()
	@CsvSource({ "-1,1,-1", "2,-3,-6", "-4,-5,20" , "-9,0,0","6,0,0"})
	public void multiplication_plusieursParam(int arg1, int arg2, int ResAttendu) 
	{
		// Arrange -- Tout est prêt !

		// Act
		int ResObtenu = cal.mul(arg1, arg2);

		// Assert
		assertEquals(ResAttendu, ResObtenu);
	}
	
	
	@Test
	void testAddDeuxNbrPos() {
		//1-Arrange
		int a=2;
		int b=3;

		//2-Act
		int s = cal.add(a,b);
		//3-Assert
		//assertEquals(reultat_attendu, resultat_obtenu)
		assertEquals(5,s);
	}
	@Test
	void testMulDeuxNbrPos() {
		//1-Arrange
		int a=2;
		int b=3;
		
		//2-Act
		int s = cal.mul(a,b);
		//3-Assert
		assertEquals(6,s);	
	}
	@Test
	void testDivDeuxNbrPos() {
		//1-Arrange
		int a=20;
		int b=0;
		
		//2-Act
		int s = cal.div(a,b);
		//3-Assert
		assertEquals(-1,s);	
	}

		
	@Timeout(2)
	@Test
	public void longCalcul_neDoitpasDepasser2sec() {
		// Arrange

		// Act
		cal.longCalcul();
		
		// Assert
		// ...
	}

	
}















